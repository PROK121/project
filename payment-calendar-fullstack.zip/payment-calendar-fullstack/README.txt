# Payment Calendar — Fullstack App

This archive contains a full backend (Express + SQLite) and frontend (React + Vite + Tailwind) setup.

## How to run locally

1. Unzip the archive.
2. In one terminal:
   ```
   cd server
   npm install
   npm run dev
   ```
3. In another terminal:
   ```
   cd client
   npm install
   npm run dev
   ```
4. Open http://localhost:5173

## Deployment

You can deploy backend to Render and frontend to Vercel using the included render.yaml and vercel.json.
